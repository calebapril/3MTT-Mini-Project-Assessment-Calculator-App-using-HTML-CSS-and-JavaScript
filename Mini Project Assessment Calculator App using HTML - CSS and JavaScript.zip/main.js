let display = document.getElementById('display');
let currentInput = '';

function appendNumber(number) {
  if (currentInput === '0') currentInput = '';
  currentInput += number;
  display.innerText = currentInput;
}

function appendOperator(operator) {
  const lastChar = currentInput.slice(-1);
  if ("+-*/".includes(lastChar)) return; // prevent double operators
  currentInput += operator;
  display.innerText = currentInput;
}

function calculate() {
  try {
    currentInput = eval(currentInput).toString();
    display.innerText = currentInput;
  } catch {
    display.innerText = "Error";
    currentInput = '';
  }
}

function clearDisplay() {
  currentInput = '';
  display.innerText = '0';
}
